 <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>DMS-Directory Management System</span>
          </div>
        </div>
      </footer>